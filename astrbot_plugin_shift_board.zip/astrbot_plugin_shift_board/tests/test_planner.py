"""排班/工时/工薪核心逻辑的自测脚本。

运行：
    python tests/test_planner.py
"""

from __future__ import annotations

import sys
import unittest
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import planner  # noqa: E402


class RestScheduleTest(unittest.TestCase):
    def test_rest_count_is_exact(self):
        for year, month in ((2026, 11), (2026, 2), (2024, 2), (2026, 12), (2025, 1)):
            for mode in (4, 6, 8):
                rests = planner.rest_days_for_month(year, month, mode, True)
                self.assertEqual(len(rests), mode, f"{year}-{month} 月休{mode}天")
                days = planner.calendar.monthrange(year, month)[1]
                self.assertTrue(all(1 <= day <= days for day in rests))
                self.assertEqual(len(set(rests)), mode)

    def test_schedule_marks_rest_and_work(self):
        profile = planner.Profile(rest_mode=4)
        slots = planner.build_month_schedule(2026, 11, profile)
        self.assertEqual(len(slots), 30)
        self.assertEqual(sum(1 for s in slots if s.kind == "rest"), 4)
        self.assertEqual(sum(1 for s in slots if s.kind == "work"), 26)
        for slot in slots:
            if slot.kind == "work":
                self.assertEqual(slot.planned_minutes, 8 * 60)
                self.assertEqual(slot.start, "09:00")
                self.assertEqual(slot.end, "18:00")

    def test_prefer_weekend_lands_on_weekend(self):
        rests = planner.rest_days_for_month(2026, 11, 8, True)
        weekends = sum(
            1 for day in rests if date(2026, 11, day).weekday() >= 5
        )
        self.assertGreaterEqual(weekends, 6, f"双休应多数落在周末：{rests}")

    def test_single_rest_is_sunday(self):
        rests = planner.rest_days_for_month(2026, 11, 4, True)
        self.assertTrue(
            all(date(2026, 11, day).weekday() == 6 for day in rests),
            f"月休 4 天应落在周日：{rests}",
        )

    def test_even_mode_ignores_weekend(self):
        rests = planner.rest_days_for_month(2026, 11, 4, False)
        self.assertEqual(len(rests), 4)


class ShiftMathTest(unittest.TestCase):
    def test_day_shift_with_break(self):
        self.assertEqual(planner.shift_minutes("09:00", "18:00", 60), 8 * 60)

    def test_night_shift_cross_day(self):
        self.assertEqual(planner.shift_minutes("22:00", "06:00", 30), 7 * 60 + 30)

    def test_short_shift_keeps_break(self):
        # 4 小时以下不扣饭休
        self.assertEqual(planner.shift_minutes("09:00", "12:00", 60), 180)

    def test_parse_time_formats(self):
        self.assertEqual(planner.parse_hhmm("9:30"), 570)
        self.assertEqual(planner.parse_hhmm("09：30"), 570)
        self.assertEqual(planner.parse_hhmm("9点"), 540)
        self.assertEqual(planner.parse_hhmm("0930"), 570)
        self.assertEqual(planner.parse_hhmm(""), 540)

    def test_month_parsing(self):
        today = date(2026, 11, 21)
        self.assertEqual(planner.parse_month("", today), "2026-11")
        self.assertEqual(planner.parse_month("2026-03", today), "2026-03")
        self.assertEqual(planner.parse_month("2026年3月", today), "2026-03")
        self.assertEqual(planner.parse_month("3", today), "2026-03")
        self.assertEqual(planner.shift_month("2026-12", 1), "2027-01")


class PayrollTest(unittest.TestCase):
    def build(self, mode=4, rate=20.0, overtime=1.5, deduction=False):
        profile = planner.Profile(
            rest_mode=mode,
            hourly_rate=rate,
            overtime_rate=overtime,
            absence_deduction=deduction,
        ).normalized()
        slots = planner.build_month_schedule(2026, 11, profile)
        return profile, slots

    def test_no_punch_no_deduction(self):
        profile, slots = self.build()
        summary = planner.summarize(
            slots, [], profile, today=date(2026, 11, 21), month_complete=False
        )
        self.assertEqual(summary["actual_minutes"], 0)
        self.assertEqual(summary["absence_minutes"], 0)
        self.assertEqual(summary["total_pay"], 0)

    def test_normal_and_overtime_pay(self):
        profile, slots = self.build(rate=20.0, overtime=1.5)
        work_days = [s for s in slots if s.is_work][:3]
        punches = []
        # 第一天正常 8h，第二天干 10h（加班 2h），第三天只干 4h
        punches.append(planner.Punch(work_days[0].day, "09:00", "18:00", 480))
        punches.append(planner.Punch(work_days[1].day, "08:00", "19:00", 600))
        punches.append(planner.Punch(work_days[2].day, "09:00", "13:00", 240))
        summary = planner.summarize(
            slots, punches, profile, today=date(2026, 11, 21), month_complete=False
        )
        self.assertEqual(summary["normal_minutes"], 480 + 480 + 240)
        self.assertEqual(summary["overtime_minutes"], 120)
        expected = (1200 / 60) * 20 + (120 / 60) * 20 * 1.5
        self.assertAlmostEqual(summary["total_pay"], round(expected, 2), places=2)

    def test_rest_day_punch_is_overtime(self):
        profile, slots = self.build(rate=20.0, overtime=1.5)
        rest_day = next(s for s in slots if not s.is_work)
        punches = [planner.Punch(rest_day.day, "09:00", "17:00", 480)]
        summary = planner.summarize(
            slots, punches, profile, today=date(2026, 11, 21), month_complete=False
        )
        self.assertEqual(summary["normal_minutes"], 0)
        self.assertEqual(summary["overtime_minutes"], 480)
        self.assertAlmostEqual(summary["overtime_pay"], round(8 * 20 * 1.5, 2))

    def test_absence_deduction_after_first_punch(self):
        profile, slots = self.build(rate=20.0, deduction=True)
        work_days = [s for s in slots if s.is_work]
        first = work_days[0]
        third = work_days[2]
        # 先打卡记录从 first 开始，中间那天漏卡，today 定在第三个工作日
        punches = [planner.Punch(first.day, "09:00", "18:00", 480)]
        summary = planner.summarize(
            slots,
            punches,
            profile,
            today=date.fromisoformat(third.day),
            month_complete=False,
        )
        self.assertEqual(summary["absence_days"], 1)
        self.assertAlmostEqual(summary["absence_deduction"], round(8 * 20, 2))
        self.assertAlmostEqual(summary["total_pay"], 0.0, places=2)

    def test_no_deduction_before_first_punch(self):
        profile, slots = self.build(rate=20.0, deduction=True)
        work_days = [s for s in slots if s.is_work]
        punches = [planner.Punch(work_days[3].day, "09:00", "18:00", 480)]
        summary = planner.summarize(
            slots,
            punches,
            profile,
            today=date.fromisoformat(work_days[3].day),
            month_complete=False,
        )
        # 首次打卡之前的工作日不算缺勤
        self.assertEqual(summary["absence_days"], 0)

    def test_fine_deducted_from_net_pay(self):
        profile, slots = self.build(rate=20.0)
        work_days = [s for s in slots if s.is_work][:2]
        punches = [
            planner.Punch(work_days[0].day, "09:00", "18:00", 480),
            planner.Punch(work_days[1].day, "09:00", "18:00", 480),
        ]
        summary = planner.summarize(
            slots,
            punches,
            profile,
            today=date(2026, 11, 21),
            month_complete=False,
            fine_total=300.0,
        )
        self.assertAlmostEqual(summary["gross_pay"], 320.0, places=2)
        self.assertAlmostEqual(summary["fine_total"], 300.0, places=2)
        self.assertAlmostEqual(summary["total_pay"], 20.0, places=2)

    def test_monthly_salary_is_fixed_base(self):
        profile = planner.Profile(
            rest_mode=4, monthly_salary=5000.0, pay_mode="monthly"
        ).normalized()
        slots = planner.build_month_schedule(2026, 11, profile)
        summary = planner.summarize(
            slots, [], profile, today=date(2026, 11, 30), month_complete=True
        )
        self.assertEqual(summary["pay_mode"], "monthly")
        self.assertAlmostEqual(summary["normal_pay"], 5000.0, places=2)
        self.assertAlmostEqual(summary["projected_pay"], 5000.0, places=2)
        self.assertGreater(summary["hourly_rate"], 0)
        self.assertAlmostEqual(
            summary["hourly_rate"], round(5000 / (summary["planned_minutes"] / 60), 2), places=1
        )

    def test_punch_on_rest_day_still_counts_attendance(self):
        profile = planner.Profile(rest_mode=4).normalized()
        slots = planner.build_month_schedule(2026, 11, profile, rest_override=[5])
        punches = [planner.Punch("2026-11-05", "09:00", "18:00", 480)]
        summary = planner.summarize(
            slots, punches, profile, today=date(2026, 11, 21), month_complete=False
        )
        self.assertEqual(summary["attended_days"], 1)
        self.assertEqual(summary["work_attended_days"], 0)
        self.assertEqual(summary["overtime_rest_days"], 1)


class SpokenPlanTest(unittest.TestCase):
    """用户口头说「5、14、18、25 休息，其余全上班」这类说法的落地规则。"""

    def test_named_rest_days_override_auto_mode(self):
        profile = planner.Profile(rest_mode=4)
        slots = planner.build_month_schedule(2026, 11, profile, rest_override=[5, 14, 18, 25])
        rest_days = [int(slot.day[8:10]) for slot in slots if slot.kind == "rest"]
        self.assertEqual(rest_days, [5, 14, 18, 25])
        self.assertEqual(sum(1 for slot in slots if slot.kind == "work"), 26)

    def test_auto_mode_still_used_without_override(self):
        profile = planner.Profile(rest_mode=4)
        slots = planner.build_month_schedule(2026, 11, profile, rest_override=None)
        self.assertEqual(sum(1 for slot in slots if slot.kind == "rest"), 4)

    def test_shift_type_is_inferred(self):
        self.assertEqual(
            planner.shift_type_label(planner.Profile(shift_start="08:00", shift_end="20:00")),
            "白班",
        )
        self.assertEqual(
            planner.shift_type_label(planner.Profile(shift_start="22:00", shift_end="06:00")),
            "夜班（跨天）",
        )

    def test_twelve_hour_day_shift(self):
        # 8:00-20:00 扣 60 分钟饭休 => 每天 11 小时有效工时
        profile = planner.Profile(shift_start="08:00", shift_end="20:00", break_minutes=60)
        self.assertEqual(profile.daily_minutes, 11 * 60)


if __name__ == "__main__":
    unittest.main(verbosity=2)
