"""提醒 / AI 工具 / 数据隔离的自测。

在 AstrBot 根目录下用 venv 运行：
    venv\\Scripts\\python.exe <本文件>
脚本使用临时数据库，不会碰真实数据。
"""

from __future__ import annotations

import asyncio
import sys
import tempfile
from datetime import date, datetime, timedelta
from pathlib import Path

PLUGIN_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PLUGIN_DIR.parent))

FAIL: list[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    print(("  ok   " if condition else "  FAIL ") + name + (f"  <- {detail}" if detail and not condition else ""))
    if not condition:
        FAIL.append(name)


class FakeContext:
    def __init__(self) -> None:
        self.sent: list[tuple[str, str]] = []
        self.routes: list[tuple] = []

    def register_web_api(self, route, handler, methods, desc) -> None:
        self.routes.append((route, methods))

    async def send_message(self, umo, chain) -> bool:
        parts = getattr(chain, "chain", chain) or []
        text = "".join(getattr(part, "text", "") or "" for part in parts)
        self.sent.append((umo, text))
        return True


class FakeEvent:
    def __init__(self, uid: str, nickname: str = "测试员", platform: str = "aiocqhttp") -> None:
        self._uid = uid
        self._nickname = nickname
        self._platform = platform
        self.unified_msg_origin = f"{platform}:GroupMessage:12345"

    def get_sender_id(self) -> str:
        return self._uid

    def get_sender_name(self) -> str:
        return self._nickname

    def get_platform_name(self) -> str:
        return self._platform

    def plain_result(self, text: str):
        return text


async def main() -> int:
    from astrbot_plugin_shift_board import ShiftBoardPlugin
    from astrbot_plugin_shift_board.planner import build_month_schedule_for
    from astrbot_plugin_shift_board.store import ShiftStore

    print("== 1) 插件实例化（含提醒任务 / AI 工具注册）")
    ctx = FakeContext()
    plugin = ShiftBoardPlugin(
        ctx,
        {
            "default_rest_mode": 4,
            "default_shift_start": "09:00",
            "default_shift_end": "18:00",
            "default_break_minutes": 60,
            "prefer_weekend": True,
            "default_hourly_rate": 20,
            "default_overtime_rate": 1.5,
            "absence_deduction": False,
            "rest_day_as_overtime": True,
            "enable_ai_punch": False,
            "remind_enabled": True,
            "remind_before_start_minutes": 30,
            "remind_before_end_minutes": 15,
        },
    )
    check("Web API 路由", len(ctx.routes) == 11)
    for name in (
        "ai_schedule",
        "ai_today",
        "ai_hours",
        "ai_pay",
        "ai_punch",
        "remind_status",
        "remind_on",
        "remind_off",
        "remind_before_start",
        "remind_before_end",
    ):
        check(f"AI/指令方法 {name}", hasattr(plugin, name))
    if plugin._reminder_task is not None and not plugin._reminder_task.done():
        plugin._reminder_task.cancel()

    print("== 2) 提醒：工作日的上班 / 下班各发一次")
    tmp = Path(tempfile.mkdtemp()) / "remind.db"
    plugin.store = ShiftStore(tmp)
    await plugin.store.init()

    user = await plugin.store.ensure_user(
        "aiocqhttp:1001",
        uid="1001",
        platform="aiocqhttp",
        nickname="早班人",
        defaults=plugin._default_profile(),
        umo="aiocqhttp:GroupMessage:12345",
    )
    check("umo 已记录", user.umo.endswith("12345"))
    check("提醒默认开启", user.remind_enabled)

    slots = build_month_schedule_for(f"{date.today():%Y-%m}", user.profile)
    await plugin.store.save_schedule(user.user_key, f"{date.today():%Y-%m}", slots)
    workdays = [item for item in slots if item.kind == "work"]
    restdays = [item for item in slots if item.kind == "rest"]
    check("存在工作日", bool(workdays))
    check("存在休息日", bool(restdays))

    workday = workdays[0]
    day = date.fromisoformat(workday.day)
    before_start = user.remind_before_start
    start_min = 9 * 60
    now_in = datetime(day.year, day.month, day.day) + timedelta(minutes=start_min - before_start + 1)
    before_count = len(ctx.sent)
    await plugin._check_one_reminder(user, now_in)
    check("上班提醒已发送", len(ctx.sent) == before_count + 1)
    check(
        "上班提醒文案温柔",
        ("早安" in ctx.sent[-1][1] or "晚上好" in ctx.sent[-1][1])
        and "09:00" in ctx.sent[-1][1]
        and "不用赶" in ctx.sent[-1][1],
        ctx.sent[-1][1],
    )
    await plugin._check_one_reminder(user, now_in)
    check("同一分钟不重复发", len(ctx.sent) == before_count + 1)

    now_out = datetime(day.year, day.month, day.day, 17, 46)
    await plugin._check_one_reminder(user, now_out)
    check("下班提醒已发送", len(ctx.sent) == before_count + 2)
    check(
        "下班提醒文案带结算承诺",
        "快收工" in ctx.sent[-1][1]
        and "18:00" in ctx.sent[-1][1]
        and "入账" in ctx.sent[-1][1],
        ctx.sent[-1][1],
    )

    print("== 3) 不打重复提醒：已有完整打卡不再催下班")
    await plugin.store.add_punch(user.user_key, workday.day, "09:00", "18:00", 480, "正常")
    fresh = await plugin.store.get_user(user.user_key)
    await plugin.store.mark_reminded(user.user_key, workday.day, "in")
    await plugin.store.prune_reminders("9999-99-99")
    before = len(ctx.sent)
    await plugin._check_one_reminder(fresh, now_out)
    check("已下班则不提醒", len(ctx.sent) == before)

    print("== 4) 休息日不提醒")
    restday = restdays[0]
    rest_date = date.fromisoformat(restday.day)
    before = len(ctx.sent)
    await plugin._check_one_reminder(fresh, datetime(rest_date.year, rest_date.month, rest_date.day, 8, 31))
    await plugin._check_one_reminder(fresh, datetime(rest_date.year, rest_date.month, rest_date.day, 17, 46))
    check("休息日 0 条提醒", len(ctx.sent) == before)

    print("== 5) 数据隔离：两个人的排班 / 打卡 / 提醒互不影响")
    other = await plugin.store.ensure_user(
        "aiocqhttp:2002",
        uid="2002",
        platform="aiocqhttp",
        nickname="另一个人",
        defaults=plugin._default_profile(),
        umo="aiocqhttp:GroupMessage:99999",
    )
    check("user_key 带平台前缀", other.user_key == "aiocqhttp:2002")
    other_punches = await plugin.store.list_punches(other.user_key, workday.day, workday.day)
    check("别人的打卡不串", other_punches == [])
    mine = await plugin.store.list_punches(user.user_key, workday.day, workday.day)
    check("自己打卡还在", len(mine) == 1)
    before = len(ctx.sent)
    await plugin._check_one_reminder(other, now_in)
    check("第二个人也收到自己的上班提醒", len(ctx.sent) == before + 1)
    check("提醒发到自己的会话", ctx.sent[-1][0] == other.umo, ctx.sent[-1][0])

    print("== 6) /提醒 开关")
    off_user = await plugin.store.get_user(other.user_key)
    await plugin.store.update_profile(other.user_key, remind_enabled=False)
    fresh_other = await plugin.store.get_user(other.user_key)
    before = len(ctx.sent)
    await plugin._check_one_reminder(fresh_other, now_in)
    check("关闭后不再推送", len(ctx.sent) == before)
    await plugin.store.update_profile(other.user_key, remind_enabled=True, remind_before_start=45)
    refreshed = await plugin.store.get_user(other.user_key)
    check("提前分钟数可改", refreshed.remind_before_start == 45)

    print("== 7) AI 工具返回内容")
    event = FakeEvent("1001", "早班人")
    text = await plugin.ai_today(event)
    check("ai_today 有输出", "上班" in text or "排休" in text, text[:60])
    text = await plugin.ai_schedule(event, "")
    check("ai_schedule 有排班", "工作日" in text, text[:60])
    text = await plugin.ai_hours(event, "本周")
    check("ai_hours 有工时", "实际" in text, text[:60])
    text = await plugin.ai_pay(event, "")
    check("ai_pay 未设时薪提示", "时薪" in text, text[:60])
    before = len(ctx.sent)
    text = await plugin.ai_punch(event, "上班")
    check("AI 打卡默认被拦", "没有开启" in text, text)
    check("AI 打卡未写库", len(ctx.sent) == before)
    again = await plugin.store.list_punches("aiocqhttp:1001", date.today().isoformat(), date.today().isoformat())
    check("库内无新增打卡", len(again) <= 1)

    print("== 8) 口头排班：指定休息日 + 12 小时班次 + 白夜班识别")
    month = f"{date.today():%Y-%m}"
    text = await plugin.ai_set_plan(
        event,
        month="",
        rest_mode="4",
        rest_days="5,14,18,25",
        shift_start="08:00",
        shift_end="20:00",
        break_minutes="60",
        daily_hours="",
    )
    check("口头排班有回执", "排班已更新" in text, text[:80])
    check("口头排班识别白班", "白班" in text, text[:80])
    stored_days = await plugin.store.get_month_rests("aiocqhttp:1001", month)
    check("指定休息日已写入", stored_days == [5, 14, 18, 25], str(stored_days))
    slots = await plugin.store.get_schedule("aiocqhttp:1001", month)
    rest_days = sorted(int(item.day[8:10]) for item in slots if item.kind == "rest")
    check("班表按指定日期排休", rest_days == [5, 14, 18, 25], str(rest_days))
    check("班表其余天数全上班", sum(1 for item in slots if item.kind == "work") == len(slots) - 4)
    refreshed = await plugin.store.get_user("aiocqhttp:1001")
    check("班次已改成 8-20", refreshed.profile.shift_start == "08:00" and refreshed.profile.shift_end == "20:00")

    text = await plugin.ai_set_plan(
        event,
        month="",
        rest_mode="",
        rest_days="",
        shift_start="22:00",
        shift_end="06:00",
        break_minutes="30",
        daily_hours="",
    )
    check("夜班自动识别", "夜班" in text, text[:80])

    print("== 9) 口头罚款：从实发工资里扣")
    text = await plugin.ai_add_fine(event, amount="200", reason="迟到", month="")
    check("罚款有回执", "已记罚款" in text, text[:80])
    check("罚款金额入账", await plugin.store.fine_total("aiocqhttp:1001", month) == 200)
    _, summary = await plugin._month_stats("aiocqhttp:1001", month, refreshed.profile)
    check("实发已扣罚款", round(summary["gross_pay"] - summary["total_pay"], 2) == 200)
    plugin.config["enable_ai_fine"] = False
    text = await plugin.ai_add_fine(event, amount="100", reason="早退")
    check("关闭后 AI 罚款被拦", "没有开启" in text, text[:80])
    plugin.config["enable_ai_fine"] = True
    plugin.config["enable_ai_plan"] = False
    text = await plugin.ai_set_plan(event, month="", rest_mode="4")
    check("关闭后 AI 改排班被拦", "没有开启" in text, text[:80])
    plugin.config["enable_ai_plan"] = True

    print("== 10) 口头月薪 / 时薪")
    text = await plugin.ai_set_pay(
        event, monthly_salary="5000", hourly_rate="", pay_mode="", overtime_rate=""
    )
    check("AI 月薪有回执", "月薪" in text, text[:80])
    refreshed = await plugin.store.get_user("aiocqhttp:1001")
    check(
        "月薪已落库并切到月薪制",
        refreshed.profile.monthly_salary == 5000 and refreshed.profile.pay_mode == "monthly",
        f"{refreshed.profile.monthly_salary}/{refreshed.profile.pay_mode}",
    )
    _, summary = await plugin._month_stats("aiocqhttp:1001", month, refreshed.profile)
    check("月薪基数就是 5000", round(summary["normal_pay"], 2) == 5000, str(summary["normal_pay"]))
    check("月薪模式有折算时薪", summary["hourly_rate"] > 0, str(summary["hourly_rate"]))

    text = await plugin.ai_set_pay(
        event, monthly_salary="", hourly_rate="18", pay_mode="", overtime_rate=""
    )
    refreshed = await plugin.store.get_user("aiocqhttp:1001")
    check(
        "口头时薪切回时薪制",
        refreshed.profile.hourly_rate == 18 and refreshed.profile.pay_mode == "hourly",
        f"{refreshed.profile.hourly_rate}/{refreshed.profile.pay_mode}",
    )
    plugin.config["enable_ai_pay"] = False
    text = await plugin.ai_set_pay(
        event, monthly_salary="8000", hourly_rate="", pay_mode="", overtime_rate=""
    )
    check("关闭后 AI 改工资被拦", "没有开启" in text, text[:80])
    plugin.config["enable_ai_pay"] = True

    print("== 11) AI 批量补打卡")
    bulk_start = date.today() - timedelta(days=10)
    bulk_end = date.today() - timedelta(days=1)
    skip_text = f"{bulk_start.day},{bulk_start.day + 1}"
    text = await plugin.ai_bulk_punch(
        event,
        start_date=bulk_start.isoformat(),
        end_date=bulk_end.isoformat(),
        start_time="09:00",
        end_time="18:00",
        skip_days=skip_text,
        note="补历史",
    )
    check("批量补录有回执", "已批量补录" in text, text[:80])
    check("跳过 2 天后补 8 天", "8 天" in text, text[:80])
    imported = await plugin.store.list_punches(
        "aiocqhttp:1001", bulk_start.isoformat(), bulk_end.isoformat()
    )
    check("批量记录已落库", len(imported) == 8, str(len(imported)))
    text = await plugin.ai_bulk_punch(
        event,
        start_date=bulk_start.isoformat(),
        end_date=bulk_end.isoformat(),
        start_time="09:00",
        end_time="18:00",
        skip_days=skip_text,
        note="",
    )
    check("重复批量不翻倍", "重复跳过 8 天" in text and "补录 0 天" in text, text[:90])
    text = await plugin.ai_bulk_punch(
        event,
        start_date=date.today().isoformat(),
        end_date=(date.today() + timedelta(days=2)).isoformat(),
        start_time="09:00",
        end_time="18:00",
    )
    check("未来日期不补", "还没到未补" in text, text[:90])
    plugin.config["enable_ai_bulk_punch"] = False
    text = await plugin.ai_bulk_punch(
        event, start_date=bulk_start.isoformat(), end_date=bulk_end.isoformat()
    )
    check("关闭后批量补卡被拦", "没有开启" in text, text[:80])
    plugin.config["enable_ai_bulk_punch"] = True

    print("== 12) 下班结算：今天入账多少钱")
    await plugin.ai_set_pay(
        event, monthly_salary="", hourly_rate="18", pay_mode="hourly", overtime_rate=""
    )
    refreshed = await plugin.store.get_user("aiocqhttp:1001")
    _, summary = await plugin._month_stats("aiocqhttp:1001", month, refreshed.profile)
    worked = next(
        (d for d in summary["days"] if d.kind == "work" and d.actual_minutes > 0),
        None,
    )
    check("有可结算的工作日", worked is not None)
    if worked:
        pay, _ = await plugin._day_earnings(refreshed, date.fromisoformat(worked.day))
        expect = (
            worked.normal_minutes / 60 * summary["hourly_rate"]
            + worked.overtime_minutes
            / 60
            * summary["hourly_rate"]
            * refreshed.profile.overtime_rate
        )
        check("时薪制日结金额正确", abs(pay - expect) < 0.01, f"{pay} vs {expect}")
    await plugin.ai_set_pay(
        event, monthly_salary="5000", hourly_rate="", pay_mode="monthly", overtime_rate=""
    )
    refreshed = await plugin.store.get_user("aiocqhttp:1001")
    if worked:
        pay_monthly, summary_monthly = await plugin._day_earnings(
            refreshed, date.fromisoformat(worked.day)
        )
        check(
            "月薪制日结=日薪+加班",
            pay_monthly > 0 and summary_monthly["pay_mode"] == "monthly",
            str(pay_monthly),
        )

    print()
    if FAIL:
        print("失败项：" + "、".join(FAIL))
        return 1
    print("全部通过 ✅")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
