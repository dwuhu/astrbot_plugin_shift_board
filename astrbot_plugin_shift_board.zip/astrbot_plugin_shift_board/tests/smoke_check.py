"""装到 AstrBot 后的冒烟自检：导入插件包 + 跑一遍存储 / 统计 / 渲染。

用法（在 AstrBot 根目录下）：
    venv\\Scripts\\python.exe <本文件路径>
"""

from __future__ import annotations

import asyncio
import json
import sys
import tempfile
from datetime import date
from pathlib import Path

PLUGIN_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PLUGIN_DIR.parent))

FAIL = []


def check(name: str, condition: bool, detail: str = "") -> None:
    print(("  ok   " if condition else "  FAIL ") + name + (f"  <- {detail}" if detail and not condition else ""))
    if not condition:
        FAIL.append(name)


def main() -> int:
    print("== 1) 导入插件包（验证 AstrBot 依赖与相对导入）")
    try:
        import astrbot_plugin_shift_board as pkg  # noqa: F401
        from astrbot_plugin_shift_board import ShiftBoardPlugin, main, planner, render, store
        check("插件包导入", True)
        check("ShiftBoardPlugin 存在", hasattr(ShiftBoardPlugin, "api_state"))
        check("指令组已注册", all(hasattr(ShiftBoardPlugin, x) for x in ("shift_group", "punch_group", "hours_group", "pay_group")))
    except Exception as exc:  # noqa: BLE001
        import traceback
        traceback.print_exc()
        check("插件包导入", False, repr(exc))
        return 1

    print("== 2) 配置 Schema")
    schema_path = PLUGIN_DIR / "_conf_schema.json"
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    check("_conf_schema.json 可解析", isinstance(schema, dict) and bool(schema))
    defaults = {k: v.get("default") for k, v in schema.items() if isinstance(v, dict)}
    check("配置项齐全", {"default_rest_mode", "default_shift_start", "default_shift_end", "default_break_minutes", "default_hourly_rate"} <= set(schema))

    print("== 3) 存储 + 统计 + 渲染（临时库，不碰真实数据）")
    tmp = Path(tempfile.mkdtemp()) / "smoke.db"
    db = store.ShiftStore(tmp)
    profile = planner.Profile(rest_mode=4, shift_start="09:00", shift_end="18:00", break_minutes=60, hourly_rate=22.0).normalized()
    asyncio.run(_flow(db, profile, planner, render, store))

    print("== 4) WebUI 静态文件")
    page = PLUGIN_DIR / "pages" / "shift-board"
    for name in ("index.html", "app.js", "style.css"):
        check(f"pages/{name}", (page / name).is_file())
    html = (page / "index.html").read_text(encoding="utf-8")
    check("页面挂载 bridge", "AstrBotPluginPage" in (page / "app.js").read_text(encoding="utf-8"))
    check("页面引用相对资源", "./style.css" in html and "./app.js" in html)

    print("== 5) API 路由清单")
    recorded: list[tuple] = []

    class _Ctx:
        def register_web_api(self, route, handler, methods, desc):
            recorded.append((route, methods))

    plugin = object.__new__(main.ShiftBoardPlugin)
    plugin.context = _Ctx()
    main.ShiftBoardPlugin._register_web_apis(plugin)
    expected = {
        f"/{main.PLUGIN_NAME}/state": "GET",
        f"/{main.PLUGIN_NAME}/profile": "POST",
        f"/{main.PLUGIN_NAME}/mode": "POST",
        f"/{main.PLUGIN_NAME}/regenerate": "POST",
        f"/{main.PLUGIN_NAME}/punch": "POST",
        f"/{main.PLUGIN_NAME}/punch/delete": "POST",
        f"/{main.PLUGIN_NAME}/background": "GET",
        f"/{main.PLUGIN_NAME}/background/save": "POST",
        f"/{main.PLUGIN_NAME}/data/export": "GET",
        f"/{main.PLUGIN_NAME}/data/import": "POST",
        f"/{main.PLUGIN_NAME}/punches/import": "POST",
    }
    got = {route: methods[0] for route, methods in recorded}
    check("11 条 Web API 路由", got == expected, str(got))

    print("== 6) 打卡 CSV 解析")
    rows = main._read_csv_rows(
        "日期,上班,下班,备注\n2026-11-05,09:00,18:00,补卡\n11-06,9点,21:30,夜班\n"
    )
    check("CSV 跳过表头", len(rows) == 2, str(rows))
    check(
        "CSV 日期解析",
        main._csv_day("2026-11-05") == date(2026, 11, 5)
        and main._csv_day("11月6日") == date(2026, 11, 6)
        and main._csv_day("20261105") == date(2026, 11, 5),
    )
    check("CSV 时间解析", main._csv_time("9点") == "09:00" and main._csv_time("2130") == "21:30")
    check(
        "Excel 秒数时间可识别",
        main._csv_time("08:00:00") == "08:00"
        and main._csv_time("20:30:00") == "20:30",
    )
    named = main._read_csv_rows(
        "姓名,日期,上班时间,下班时间\n张三,2026-11-05,08:00:00,20:00:00\n"
    )
    check(
        "表头带姓名也能对列",
        len(named) == 1
        and named[0][0] == "2026-11-05"
        and main._csv_time(named[0][1]) == "08:00"
        and main._csv_time(named[0][2]) == "20:00",
        str(named),
    )
    merged = main._read_csv_rows("2026-11-06,8:00-20:00\n")
    check(
        "同格时段可拆分",
        len(merged) == 1
        and len(merged[0]) >= 3
        and main._csv_time(merged[0][1]) == "08:00"
        and main._csv_time(merged[0][2]) == "20:00",
        str(merged),
    )
    check("CSV 非法日期返回 None", main._csv_day("不知道") is None)

    print()
    if FAIL:
        print("失败项：" + "、".join(FAIL))
        return 1
    print("全部通过 ✅")
    return 0


async def _flow(db, profile, planner, render, store) -> None:
    month = f"{date.today():%Y-%m}"
    record = await db.ensure_user("u1", uid="10001", platform="aiocqhttp", nickname="测试员", defaults=profile)
    check("建用户", record.user_key == "u1" and record.profile.hourly_rate == 22.0)

    await db.set_setting("background", json.dumps({"image": "preset:aurora", "blur": 18.0, "dim": 0.6}))
    check(
        "背景设置落库读回",
        json.loads(await db.get_setting("background", "{}")) == {"image": "preset:aurora", "blur": 18.0, "dim": 0.6},
    )
    check("未设置的 key 走默认值", await db.get_setting("nothing_here", "fallback") == "fallback")

    await db.set_month_rests("u1", "2026-11", [5, 14, 18, 25])
    check("指定休息日落库读回", await db.get_month_rests("u1", "2026-11") == [5, 14, 18, 25])
    await db.clear_month_rests("u1", "2026-11")
    check("清空指定休息日后回到自动", await db.get_month_rests("u1", "2026-11") is None)

    await db.add_fine("u1", "2026-11", 200, "迟到")
    await db.add_fine("u1", "2026-11", 100, "早退")
    check("罚款累计", await db.fine_total("u1", "2026-11") == 300)
    check("罚款明细笔数", len(await db.list_fines("u1", "2026-11")) == 2)
    check("清空罚款", await db.clear_fines("u1", "2026-11") == 2)

    slots = planner.build_month_schedule_for(month, record.profile)
    check("整月排班天数", len(slots) >= 28, str(len(slots)))
    await db.save_schedule("u1", month, slots)
    loaded = await db.get_schedule("u1", month)
    check("班表落库/读回", len(loaded) == len(slots))

    first_work = next(s for s in slots if s.kind == "work")
    await db.add_punch("u1", first_work.day, "09:00", "18:00", 480, "冒烟")
    punches = await db.list_punches("u1", first_work.day, first_work.day)
    check("打卡落库", len(punches) == 1 and punches[0].minutes == 480)

    summary = planner.summarize(loaded, punches, record.profile, today=date.today())
    check("工时汇总字段", {"actual_minutes", "planned_minutes", "overtime_minutes", "total_pay", "completion"} <= set(summary))
    check("实记工时计入", summary["actual_minutes"] >= 480, str(summary["actual_minutes"]))

    text = render.month_text(month, record.nickname, record.profile, [_day_dict(m) for m in summary["days"]], summary)
    check("月历文本渲染", bool(text) and "测试员" in text)

    html = render.month_html(month, record.nickname, record.profile, [_day_dict(m) for m in summary["days"]], summary)
    check("月历 HTML 渲染", "<" in html and len(html) > 200)

    await db.update_profile("u1", rest_mode=8, hourly_rate=25.0)
    updated = await db.get_user("u1")
    check("改配置", updated.profile.rest_mode == 8 and updated.profile.hourly_rate == 25.0)

    backup = await db.export_all()
    check(
        "备份含七张表",
        {"profiles", "schedules", "punches", "reminders", "fines", "month_rests", "settings"}
        <= set(backup["tables"]),
    )
    fresh = store.ShiftStore(Path(tempfile.mkdtemp()) / "import.db")
    counts = await fresh.import_all(backup, replace=True)
    check("整库导入有计数", counts.get("profiles", 0) >= 1 and counts.get("punches", 0) >= 1)
    again = await fresh.import_all(backup, replace=False)
    after = await fresh.export_all()
    check(
        "重复合并导入不翻倍",
        again.get("punches", 0) == 0
        and len(after["tables"]["punches"]) == len(backup["tables"]["punches"]),
    )


def _day_dict(slot) -> dict:
    return {
        "day": slot.day,
        "weekday": slot.weekday,
        "kind": slot.kind,
        "start": slot.start,
        "end": slot.end,
        "planned_minutes": slot.planned_minutes,
        "actual_minutes": slot.actual_minutes,
        "normal_minutes": slot.normal_minutes,
        "overtime_minutes": slot.overtime_minutes,
        "status": slot.status,
        "attended": slot.attended,
        "absent": slot.absent,
        "is_today": slot.is_today,
        "is_future": slot.is_future,
        "punches": [],
    }


if __name__ == "__main__":
    raise SystemExit(main())
