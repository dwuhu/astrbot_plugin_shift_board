/* 排班工坊 WebUI —— 日历 + 工时看板 */
const bridge = window.AstrBotPluginPage;
const $ = (id) => document.getElementById(id);
const WEEK_CN = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"];

const state = {
  users: [],
  active: null,
  month: "",
  monthLabel: "",
  days: [],
  summary: null,
  selectedDay: null,
};

/* ------------------------------------------------------------------ */
/* 小工具                                                              */
/* ------------------------------------------------------------------ */
function unwrap(response) {
  if (response && response.status === "ok" && response.data !== undefined) {
    return response.data;
  }
  return response;
}

function hours(minutes) {
  return `${(Number(minutes || 0) / 60).toFixed(1)}h`;
}

function money(value) {
  const number = Number(value || 0);
  return `¥${number.toLocaleString("zh-CN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

/* 后端校验失败时返回 {status:"error", message}，优先取这句中文提示 */
function failText(error) {
  const payload = error && error.response && error.response.data;
  if (payload && typeof payload === "object" && payload.message) {
    return String(payload.message);
  }
  return (error && error.message) || "请求失败，请稍后重试";
}

/* ------------------------------------------------------------------ */
/* 背景与外观                                                          */
/* ------------------------------------------------------------------ */
const BG_PRESETS = {
  aurora:
    "radial-gradient(circle at 18% 12%, rgba(56,189,248,.58), transparent 55%), radial-gradient(circle at 84% 10%, rgba(240,171,252,.5), transparent 52%), radial-gradient(circle at 50% 104%, rgba(250,204,21,.28), transparent 60%), linear-gradient(160deg, #060a15, #0a1022 55%, #131c38)",
  sakura:
    "radial-gradient(circle at 18% 18%, rgba(251,207,232,.55), transparent 55%), radial-gradient(circle at 82% 22%, rgba(196,181,253,.45), transparent 55%), radial-gradient(circle at 62% 96%, rgba(244,114,182,.3), transparent 60%), linear-gradient(160deg, #180f22, #2a1630 55%, #0f1224)",
  deep:
    "radial-gradient(circle at 28% 8%, rgba(59,130,246,.48), transparent 55%), radial-gradient(circle at 76% 78%, rgba(14,165,233,.36), transparent 62%), linear-gradient(165deg, #03060f, #060d1f 60%, #0b1530)",
  dawn:
    "radial-gradient(circle at 14% 82%, rgba(251,146,60,.48), transparent 55%), radial-gradient(circle at 82% 16%, rgba(244,114,182,.38), transparent 55%), linear-gradient(160deg, #190d16, #2b1420 55%, #0f1020)",
  mint:
    "radial-gradient(circle at 22% 16%, rgba(52,211,153,.46), transparent 55%), radial-gradient(circle at 78% 84%, rgba(34,211,238,.42), transparent 58%), linear-gradient(160deg, #050f14, #07181f 55%, #0a1a2a)",
};

const appearance = { image: "", blur: 8, dim: 45 };
let bgTimer = null;

function applyAppearance() {
  const body = document.body;
  const hasImage = Boolean(appearance.image);
  body.classList.toggle("has-photo", hasImage);

  if (!hasImage) {
    body.style.removeProperty("--bg-image");
  } else if (appearance.image.startsWith("preset:")) {
    const key = appearance.image.slice("preset:".length);
    body.style.setProperty("--bg-image", BG_PRESETS[key] || BG_PRESETS.aurora);
  } else {
    body.style.setProperty("--bg-image", `url("${appearance.image}")`);
  }

  body.style.setProperty("--bg-blur", `${appearance.blur}px`);
  body.style.setProperty("--bg-dim", String(appearance.dim / 100));

  $("bg-blur-val").textContent = `${appearance.blur}px`;
  $("bg-dim-val").textContent = `${appearance.dim}%`;
  $("input-bg-blur").value = String(appearance.blur);
  $("input-bg-dim").value = String(appearance.dim);

  let label = "默认";
  if (hasImage) {
    label = appearance.image.startsWith("preset:") ? "预设背景" : "自定义图片";
  }
  $("bg-state").textContent = label;

  document.querySelectorAll("#preset-grid .preset").forEach((el) => {
    el.classList.toggle("active", appearance.image === `preset:${el.dataset.preset}`);
  });
}

async function loadAppearance() {
  try {
    const data = unwrap(await bridge.apiGet("background"));
    if (data && typeof data === "object") {
      appearance.image = data.image || "";
      appearance.blur = Number(data.blur ?? 8);
      appearance.dim = Math.round(Number(data.dim ?? 0.45) * 100);
    }
  } catch (error) {
    console.warn("background load failed", error);
  }
  applyAppearance();
}

async function persistAppearance() {
  if (bgTimer) {
    clearTimeout(bgTimer);
    bgTimer = null;
  }
  try {
    const data = unwrap(
      await bridge.apiPost("background/save", {
        image: appearance.image,
        blur: appearance.blur,
        dim: appearance.dim / 100,
      })
    );
    if (data && typeof data === "object") {
      appearance.blur = Number(data.blur ?? appearance.blur);
      appearance.dim = Math.round(Number(data.dim ?? appearance.dim / 100) * 100);
      applyAppearance();
    }
    $("bg-hint").textContent = appearance.image
      ? "已保存，下次打开还是这个背景。"
      : "已恢复默认背景。";
  } catch (error) {
    $("bg-hint").textContent = `背景保存失败：${failText(error)}`;
  }
}

function queueAppearanceSave(delay = 380) {
  if (bgTimer) clearTimeout(bgTimer);
  bgTimer = setTimeout(() => {
    bgTimer = null;
    persistAppearance();
  }, delay);
}

function readBackgroundFile(file) {  if (!file) return;
  if (!file.type.startsWith("image/")) {
    $("bg-hint").textContent = "只能上传图片文件。";
    return;
  }
  $("bg-hint").textContent = "正在读取图片…";
  const reader = new FileReader();
  reader.onerror = () => {
    $("bg-hint").textContent = "图片读取失败，换一张试试。";
  };
  reader.onload = () => {
    const img = new Image();
    img.onerror = () => {
      $("bg-hint").textContent = "这张图片打不开，换一张试试。";
    };
    img.onload = () => {
      const maxWidth = 1600;
      const scale = Math.min(1, maxWidth / (img.width || maxWidth));
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(img.width * scale));
      canvas.height = Math.max(1, Math.round(img.height * scale));
      const ctx = canvas.getContext("2d");
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      try {
        appearance.image = canvas.toDataURL("image/jpeg", 0.82);
      } catch (error) {
        $("bg-hint").textContent = "图片压缩失败，换一张试试。";
        return;
      }
      applyAppearance();
      $("bg-hint").textContent = `已载入 ${canvas.width}×${canvas.height}，正在保存…`;
      persistAppearance();
    };
    img.src = reader.result;
  };
  reader.readAsDataURL(file);
}

function currentMonth() {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
}

function shiftMonth(month, delta) {
  const [year, mon] = month.split("-").map(Number);
  const index = year * 12 + (mon - 1) + delta;
  return `${Math.floor(index / 12)}-${String((index % 12 + 1)).padStart(2, "0")}`;
}

function dayNumber(iso) {
  return Number(iso.slice(8, 10));
}

function setHint(text, kind = "") {
  const el = $("save-hint");
  el.textContent = text || "";
  el.className = `hint ${kind}`.trim();
}

function setStatus(text) {
  $("status-text").textContent = text;
}

/* ------------------------------------------------------------------ */
/* 数据加载                                                            */
/* ------------------------------------------------------------------ */
async function load() {
  const userKey = state.active ? state.active.user_key : "";
  const month = state.month || currentMonth();
  const data = unwrap(
    await bridge.apiGet("state", { month, user: userKey })
  );
  applyState(data);
}

function applyState(data) {
  if (!data) return;
  state.users = data.users || [];
  state.active = data.active || null;
  state.month = data.month || currentMonth();
  state.monthLabel = data.month_label || state.month;
  state.days = data.days || [];
  state.summary = data.summary || null;

  renderUsers();
  renderHeader();
  renderCalendar();
  renderHero();
  renderMetrics();
  renderSettings();
  renderChart();

  const today = new Date().toISOString().slice(0, 10);
  const todayCell = state.days.find((day) => day.day === today);
  setStatus(
    state.active
      ? `${state.monthLabel} · ${state.users.length} 位员工 · 今天${
          todayCell ? (todayCell.kind === "rest" ? "休息" : "上班") : "未排班"
        }`
      : "还没有员工数据"
  );
}

function renderUsers() {
  const select = $("user-select");
  select.innerHTML = "";
  if (!state.users.length) {
    const option = document.createElement("option");
    option.textContent = "暂无员工";
    select.appendChild(option);
    select.disabled = true;
    return;
  }
  select.disabled = false;
  for (const user of state.users) {
    const option = document.createElement("option");
    option.value = user.user_key;
    const suffix = user.uid && user.uid !== user.nickname ? ` · ${String(user.uid).slice(-4)}` : "";
    option.textContent = `${user.nickname}${suffix}`;
    if (state.active && user.user_key === state.active.user_key) {
      option.selected = true;
    }
    select.appendChild(option);
  }
}

function renderHeader() {
  $("month-label").textContent = state.monthLabel;
  const active = state.active;
  if (!active) {
    $("shift-hint").textContent = "—";
    return;
  }
  const label = (state.summary && state.summary.shift_label) || "";
  $("shift-hint").textContent = `${active.shift_start}-${active.shift_end}${label ? `（${label}）` : ""} · 扣休 ${active.break_minutes} 分 · 每班 ${hours(active.daily_minutes)}`;
  for (const button of $("mode-switch").querySelectorAll("button")) {
    button.classList.toggle("active", Number(button.dataset.mode) === active.rest_mode);
  }
}

/* ------------------------------------------------------------------ */
/* 日历                                                                */
/* ------------------------------------------------------------------ */
function renderCalendar() {
  const grid = $("calendar-grid");
  grid.innerHTML = "";

  if (!state.active) {
    grid.innerHTML =
      '<div class="empty-state" style="grid-column: span 7">还没有数据。先在 QQ 里发送「/排班 查看」生成班表，再回到这里。</div>';
    return;
  }

  const [year, month] = state.month.split("-").map(Number);
  const leading = (new Date(`${state.month}-01T00:00:00`).getDay() + 6) % 7;

  for (let i = 0; i < leading; i += 1) {
    const blank = document.createElement("div");
    blank.className = "cell empty";
    grid.appendChild(blank);
  }

  for (const day of state.days) {
    const cell = document.createElement("div");
    const classes = ["cell"];
    if (day.kind === "rest") {
      classes.push("rest");
      if (day.actual_minutes) classes.push("overtime");
    } else if (day.status === "done") {
      classes.push("work", "done");
    } else if (day.status === "absent") {
      classes.push("work", "absent");
    } else {
      classes.push("work");
    }
    if (day.is_today) classes.push("today");
    cell.className = classes.join(" ");
    cell.style.animationDelay = `${Math.min(dayNumber(day.day), 31) * 8}ms`;

    let tag = "休息";
    if (day.kind === "rest") {
      tag = day.actual_minutes ? `休班加班 ${hours(day.actual_minutes)}` : "休息";
    } else if (day.status === "done") {
      tag = `${day.start}-${day.end} · 实 ${hours(day.actual_minutes)}`;
    } else if (day.status === "absent") {
      tag = `${day.start}-${day.end} · 缺勤`;
    } else {
      tag = `${day.start}-${day.end} · ${hours(day.planned_minutes)}`;
    }
    if (day.overtime_minutes && day.kind === "work") {
      tag += ` · 加 ${hours(day.overtime_minutes)}`;
    }

    cell.innerHTML = `
      <div class="num">${dayNumber(day.day)}<small>${WEEK_CN[day.weekday] || ""}</small></div>
      <span class="badge"></span>
      <div class="tag">${tag}</div>
    `;
    cell.addEventListener("click", () => openDrawer(day.day));
    grid.appendChild(cell);
  }
}

/* ------------------------------------------------------------------ */
/* 看板                                                                */
/* ------------------------------------------------------------------ */
function renderHero() {
  const active = state.active;
  const summary = state.summary;
  if (!active || !summary) {
    $("total-pay").textContent = "¥0.00";
    $("projected-pay").textContent = "全月预计 ¥0.00";
    $("completion-value").textContent = "0%";
    $("ring-fill").style.strokeDashoffset = 314;
    return;
  }
  $("total-pay").textContent = money(summary.total_pay);
  $("projected-pay").textContent = `全月预计 ${money(summary.projected_pay)}`;
  if (summary.pay_mode === "monthly") {
    $("chip-rate").textContent = `月薪 ${money(summary.monthly_salary)}`;
  } else {
    $("chip-rate").textContent = `时薪 ${money(summary.hourly_rate)}/h`;
  }
  $("chip-daily").textContent = `日薪 ${money(summary.daily_pay)}`;
  const fineTotal = Number(summary.fine_total || 0);
  const fineChip = $("chip-fine");
  fineChip.textContent = `罚款 -${money(fineTotal)}`;
  fineChip.style.display = fineTotal > 0 ? "" : "none";

  const completion = Math.max(0, Math.min(100, Number(summary.completion || 0)));
  $("completion-value").textContent = `${completion.toFixed(0)}%`;
  $("ring-fill").style.strokeDashoffset = String(314 * (1 - completion / 100));
}

function renderMetrics() {
  const summary = state.summary;
  if (!summary) {
    for (const id of ["m-actual", "m-overtime", "m-attended", "m-rest"]) {
      $(id).textContent = "0";
    }
    return;
  }
  $("m-actual").textContent = hours(summary.actual_minutes);
  $("m-planned").textContent = `计划 ${hours(summary.planned_minutes)}`;
  $("m-overtime").textContent = hours(summary.overtime_minutes);
  const worked = summary.work_attended_days ?? summary.attended_days;
  $("m-attended").textContent = `${summary.attended_days}`;
  $("m-absence").textContent = `工作日出勤 ${worked} / ${summary.work_days} · 缺勤 ${summary.absence_days}`;
  $("m-rest").textContent = String(summary.rest_days);
  $("m-rest-ot").textContent = `休班加班 ${summary.overtime_rest_days} 天`;
}

function renderSettings() {
  const active = state.active;
  if (!active) return;
  $("input-rate").value = active.hourly_rate;
  $("input-monthly").value = active.monthly_salary || 0;
  $("input-pay-mode").value = active.pay_mode || "hourly";
  $("input-overtime").value = active.overtime_rate;
  $("input-start").value = active.shift_start;
  $("input-end").value = active.shift_end;
  $("input-break").value = active.break_minutes;
  $("input-weekend").checked = Boolean(active.prefer_weekend);
  $("input-remind").checked = Boolean(active.remind_enabled);
  $("input-remind-start").value = String(active.remind_before_start ?? 30);
  $("input-remind-end").value = String(active.remind_before_end ?? 15);
}

function renderChart() {
  const container = $("bar-chart");
  container.innerHTML = "";
  const today = new Date().toISOString().slice(0, 10);
  let recent = state.days.filter((day) => day.day <= today).slice(-14);
  if (!recent.length) recent = state.days.slice(0, 14);
  if (!recent.length) {
    $("chart-total").textContent = "—";
    return;
  }

  const maxMinutes = Math.max(...recent.map((day) => day.actual_minutes), 60);
  let total = 0;
  for (const day of recent) {
    total += day.actual_minutes;
    const bar = document.createElement("div");
    bar.className = `bar ${day.kind === "rest" ? "rest" : ""}`;
    const height = Math.max(3, Math.round((day.actual_minutes / maxMinutes) * 100));
    bar.innerHTML = `
      <div class="fill" style="height:${height}%"></div>
      <span>${dayNumber(day.day)}</span>
    `;
    bar.title = `${day.day} · ${hours(day.actual_minutes)}`;
    container.appendChild(bar);
  }
  $("chart-total").textContent = `合计 ${hours(total)}`;
}

/* ------------------------------------------------------------------ */
/* 详情抽屉                                                            */
/* ------------------------------------------------------------------ */
function openDrawer(isoDate) {
  const day = state.days.find((item) => item.day === isoDate);
  if (!day) return;
  state.selectedDay = isoDate;

  const [year, month, dateNum] = isoDate.split("-");
  $("drawer-title").textContent = `${Number(month)}月${Number(dateNum)}日 · ${WEEK_CN[day.weekday]}`;
  $("drawer-shift").textContent =
    day.kind === "rest"
      ? `休息日 · 今日已记 ${hours(day.actual_minutes)}`
      : `班次 ${day.start}-${day.end} · 计划 ${hours(day.planned_minutes)} · 实记 ${hours(day.actual_minutes)}`;

  const list = $("punch-list");
  list.innerHTML = "";
  if (!day.punches.length) {
    list.innerHTML = '<div class="punch-row"><span class="p-hours">这一天还没有打卡记录</span></div>';
  }
  for (const punch of day.punches) {
    const row = document.createElement("div");
    row.className = "punch-row";
    row.innerHTML = `
      <span class="p-time">${punch.start} - ${punch.end || "进行中"}</span>
      <span class="p-hours">${punch.open ? "计时中" : hours(punch.minutes)}</span>
    `;
    if (punch.id) {
      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "icon-mini";
      remove.textContent = "×";
      remove.title = "删除这条打卡";
      remove.addEventListener("click", () => deletePunch(punch.id));
      row.appendChild(remove);
    }
    list.appendChild(row);
  }

  $("punch-start").value = day.start || "09:00";
  $("punch-end").value = day.end || "18:00";
  $("punch-hint").textContent = "";

  const drawer = $("drawer");
  drawer.setAttribute("aria-hidden", "false");
  drawer.classList.add("open");
}

function closeDrawer() {
  const drawer = $("drawer");
  drawer.classList.remove("open");
  drawer.setAttribute("aria-hidden", "true");
  state.selectedDay = null;
}

/* ------------------------------------------------------------------ */
/* 交互                                                                */
/* ------------------------------------------------------------------ */
/* ------------------------------------------------------------------ */
/* 数据导入导出                                                        */
/* ------------------------------------------------------------------ */
function readTextFile(file, onText, onError) {
  const reader = new FileReader();
  reader.onerror = () => onError && onError();
  reader.onload = () => onText(String(reader.result || ""));
  reader.readAsText(file, "utf-8");
}

async function exportBackup() {
  const hint = $("data-hint");
  hint.textContent = "正在打包整库备份…";
  try {
    const data = unwrap(await bridge.apiGet("data/export"));
    if (!data || !data.tables) throw new Error("备份内容为空");
    const text = JSON.stringify(data, null, 2);
    const blob = new Blob([text], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `shift_board_backup_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
    const total = Object.values(data.tables).reduce(
      (sum, rows) => sum + (Array.isArray(rows) ? rows.length : 0),
      0
    );
    hint.textContent = `备份已下载，共 ${total} 条记录（含 ${Object.keys(data.tables).length} 张表）。`;
  } catch (error) {
    hint.textContent = `导出失败：${failText(error)}`;
  }
}

function importBackupFile(file) {
  const hint = $("data-hint");
  readTextFile(
    file,
    async (text) => {
      let backup;
      try {
        backup = JSON.parse(text);
      } catch (error) {
        hint.textContent = "这个文件不是合法的 JSON，确认选的是备份文件。";
        return;
      }
      if (!backup || !backup.tables) {
        hint.textContent = "文件里没有 tables，不是排班工坊的备份。";
        return;
      }
      const replace = $("import-replace").checked;
      if (replace && !window.confirm("覆盖导入会先清空现有全部数据，确定继续？")) {
        return;
      }
      hint.textContent = "正在导入，请稍等…";
      try {
        const result = unwrap(
          await bridge.apiPost("data/import", { payload: backup, replace })
        );
        const counts = (result && result.counts) || {};
        const total = Object.values(counts).reduce((sum, value) => sum + Number(value || 0), 0);
        let textHint = `导入完成，共写入 ${total} 条${replace ? "（已覆盖原有数据）" : "（合并模式，重复打卡自动跳过）"}。`;
        const months = result.months || [];
        if (months.length && !months.includes(state.month)) {
          const current = new Date().toISOString().slice(0, 7);
          const target = months.filter((month) => month <= current).pop() || months[months.length - 1];
          state.month = target;
          textHint += ` 备份数据主要在 ${target}，已帮你切过去查看。`;
        }
        hint.textContent = textHint;
        await safeLoad();
      } catch (error) {
        hint.textContent = `导入失败：${failText(error)}`;
      }
    },
    () => {
      hint.textContent = "文件读取失败，换一个文件试试。";
    }
  );
}

function importCsvFile(file) {
  const hint = $("data-hint");
  if (!state.active) {
    hint.textContent = "先在左上角选一个员工，再导入打卡 CSV。";
    return;
  }
  const userKey = state.active.user_key;
  readTextFile(
    file,
    async (text) => {
      hint.textContent = "正在导入打卡记录…";
      try {
        const result = unwrap(
          await bridge.apiPost("punches/import", { user: userKey, csv: text })
        );
        let textHint = `打卡导入完成：新增 ${result.imported} 条，重复跳过 ${result.skipped} 条`;
        if (result.invalid) textHint += `，无法识别 ${result.invalid} 条`;
        textHint += "。";

        const months = result.months || [];
        if (months.length) {
          const latest = months[months.length - 1];
          if (latest.month !== state.month) {
            state.month = latest.month;
            textHint += ` 打卡集中在 ${latest.month}，已帮你切到这个月查看。`;
          } else {
            textHint += ` 打卡日期 ${result.first_day} ~ ${result.last_day}。`;
          }
        }
        if (result.bad_rows && result.bad_rows.length) {
          textHint += ` 没认出这几行：${result.bad_rows.join("；")}。日期写 2026-11-05，时间写 09:00。`;
        }
        hint.textContent = textHint;
        await safeLoad();
      } catch (error) {
        hint.textContent = `导打卡失败：${failText(error)}`;
      }
    },
    () => {
      hint.textContent = "文件读取失败，换一个文件试试。";
    }
  );
}

function bindEvents() {
  $("btn-export").addEventListener("click", exportBackup);
  $("btn-import").addEventListener("click", () => $("file-json").click());
  $("btn-import-csv").addEventListener("click", () => $("file-csv").click());
  $("file-json").addEventListener("change", (event) => {
    const file = event.target.files && event.target.files[0];
    if (file) importBackupFile(file);
    event.target.value = "";
  });
  $("file-csv").addEventListener("change", (event) => {
    const file = event.target.files && event.target.files[0];
    if (file) importCsvFile(file);
    event.target.value = "";
  });

  $("preset-grid").addEventListener("click", (event) => {
    const button = event.target.closest(".preset");
    if (!button) return;
    appearance.image = `preset:${button.dataset.preset}`;
    applyAppearance();
    persistAppearance();
  });

  $("btn-bg-upload").addEventListener("click", () => {
    $("bg-file").click();
  });

  $("bg-file").addEventListener("change", (event) => {
    readBackgroundFile(event.target.files && event.target.files[0]);
    event.target.value = "";
  });

  $("btn-bg-clear").addEventListener("click", () => {
    appearance.image = "";
    applyAppearance();
    $("bg-hint").textContent = "正在恢复默认背景…";
    persistAppearance();
  });

  $("input-bg-blur").addEventListener("input", (event) => {
    appearance.blur = Number(event.target.value);
    applyAppearance();
    queueAppearanceSave();
  });

  $("input-bg-dim").addEventListener("input", (event) => {
    appearance.dim = Number(event.target.value);
    applyAppearance();
    queueAppearanceSave();
  });

  $("user-select").addEventListener("change", async (event) => {
    const key = event.target.value;
    state.active = state.users.find((user) => user.user_key === key) || null;
    await safeLoad();
  });

  $("mode-switch").addEventListener("click", async (event) => {
    const button = event.target.closest("button[data-mode]");
    if (!button || !state.active) return;
    const mode = Number(button.dataset.mode);
    if (mode === state.active.rest_mode) return;
    button.disabled = true;
    try {
      const data = unwrap(
        await bridge.apiPost("mode", {
          user: state.active.user_key,
          rest_mode: mode,
          month: state.month,
        })
      );
      applyState({ ...data, users: state.users });
      setStatus(`已切换为月休 ${mode} 天`);
    } catch (error) {
      setStatus(`切换失败：${failText(error)}`);
    } finally {
      button.disabled = false;
    }
  });

  $("month-prev").addEventListener("click", () => {
    state.month = shiftMonth(state.month || currentMonth(), -1);
    safeLoad();
  });

  $("month-next").addEventListener("click", () => {
    state.month = shiftMonth(state.month || currentMonth(), 1);
    safeLoad();
  });

  $("btn-save").addEventListener("click", async () => {
    if (!state.active) return;
    setHint("保存中…");
    try {
      const data = unwrap(
        await bridge.apiPost("profile", {
          user: state.active.user_key,
          month: state.month,
          hourly_rate: Number($("input-rate").value || 0),
          monthly_salary: Number($("input-monthly").value || 0),
          pay_mode: $("input-pay-mode").value || "hourly",
          overtime_rate: Number($("input-overtime").value || 1.5),
          shift_start: $("input-start").value || "09:00",
          shift_end: $("input-end").value || "18:00",
          break_minutes: Number($("input-break").value || 0),
          prefer_weekend: $("input-weekend").checked,
          remind_enabled: $("input-remind").checked,
          remind_before_start: Number($("input-remind-start").value || 0),
          remind_before_end: Number($("input-remind-end").value || 0),
        })
      );
      applyState({ ...data, users: state.users });
      setHint("已保存，班表与工资已同步重算。", "ok");
    } catch (error) {
      setHint(`保存失败：${failText(error)}`, "err");
    }
  });

  $("btn-regenerate").addEventListener("click", async () => {
    if (!state.active) return;
    try {
      const data = unwrap(
        await bridge.apiPost("regenerate", {
          user: state.active.user_key,
          month: state.month,
        })
      );
      applyState({ ...data, users: state.users });
      setStatus("已按当前设置重新排班");
    } catch (error) {
      setStatus(`重排失败：${failText(error)}`);
    }
  });

  $("btn-refresh").addEventListener("click", () => safeLoad());

  $("btn-punch").addEventListener("click", async () => {
    if (!state.active || !state.selectedDay) return;
    const start = $("punch-start").value;
    const end = $("punch-end").value;
    if (!start || !end) {
      $("punch-hint").textContent = "请填写上下班时间。";
      return;
    }
    try {
      const data = unwrap(
        await bridge.apiPost("punch", {
          user: state.active.user_key,
          date: state.selectedDay,
          start,
          end,
        })
      );
      const isoDate = state.selectedDay;
      applyState({ ...data, users: state.users });
      openDrawer(isoDate);
      $("punch-hint").textContent = "已补录这段工时。";
    } catch (error) {
      $("punch-hint").textContent = `补录失败：${failText(error)}`;
    }
  });

  $("btn-clear-day").addEventListener("click", async () => {
    if (!state.active || !state.selectedDay) return;
    try {
      const data = unwrap(
        await bridge.apiPost("punch/delete", {
          user: state.active.user_key,
          date: state.selectedDay,
          month: state.month,
        })
      );
      applyState({ ...data, users: state.users });
      closeDrawer();
    } catch (error) {
      $("punch-hint").textContent = `操作失败：${failText(error)}`;
    }
  });

  $("drawer-close").addEventListener("click", closeDrawer);
  $("drawer-scrim").addEventListener("click", closeDrawer);
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") closeDrawer();
  });
}

async function deletePunch(punchId) {
  if (!state.active) return;
  try {
    const data = unwrap(
      await bridge.apiPost("punch/delete", {
        user: state.active.user_key,
        id: punchId,
        month: state.month,
      })
    );
    const isoDate = state.selectedDay;
    applyState({ ...data, users: state.users });
    if (isoDate) openDrawer(isoDate);
  } catch (error) {
    $("punch-hint").textContent = `删除失败：${failText(error)}`;
  }
}

async function safeLoad() {
  try {
    setStatus("加载中…");
    await load();
  } catch (error) {
    setStatus(`加载失败：${failText(error)}`);
    $("calendar-grid").innerHTML =
      `<div class="empty-state" style="grid-column: span 7">加载失败：${failText(error)}</div>`;
  }
}

async function boot() {
  try {
    await bridge.ready();
  } catch (error) {
    console.warn("bridge ready failed", error);
  }
  bindEvents();
  state.month = currentMonth();
  await loadAppearance();
  await safeLoad();
}

boot();
